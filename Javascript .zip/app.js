const a = ['a', 'b', 'c'];
console.log(a);
console.log(a.slice(1, 2));